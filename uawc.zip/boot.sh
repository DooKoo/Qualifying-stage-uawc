#!/usr/bin/env bash

sudo apt-get install pip
sudo pip3 install flask
sudo pip3 install requests
sudo pip3 insatll urllib 